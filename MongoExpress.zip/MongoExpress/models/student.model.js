const mongoose = require('../mongo-connect/mongo.connect')

const StudentSchema = mongoose.Schema({
    _id:Number,
    name:String,
    branch:String
})
const model = mongoose.model("StudentDB",StudentSchema)


module.exports = model;