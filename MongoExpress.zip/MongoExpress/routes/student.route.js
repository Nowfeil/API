const express = require('express')
const studentModel = require('../models/student.model')
const routes = express.Router()
routes.use(express.json())
const {getStudents, postStudents,putStudents,deleteStudent,putStudentsBranch} = require('../controllers/student.controller')

routes.get("/",getStudents)

routes.post("/",postStudents)

routes.put("/:id",putStudents)

routes.put("/",putStudentsBranch)

routes.delete("/:id",deleteStudent)

module.exports = routes


// routes.get("/",async(req,res)=>{
//     let students = await studentModel.find({})
//     if(!students){
//         res.status(400).send("No Students are there in the database")
//     }else{
//         res.status(200).send(students)
//     }
        
// })

// routes.post("/",async(req,res)=>{
//     console.log(req.body);
//     try{
//         let student = await studentModel.create({
//             _id:parseInt(req.body.id),
//             name:req.body.name,
//             branch:req.body.branch
//         })
//         res.status(200).send(student);
//     }catch(err){
//         console.log("Something went wrong while adding the student in  database");
//     }
// })
// routes.put("/:id",async(req,res)=>{
//     const sid = parseInt(req.params.id)
//     const student = await studentModel.findByIdAndUpdate(sid,req.body)
//     if(!student){
//         res.status(400).send(`Student with ${sid} is not present in the database`)
//     }else{
//         res.status(200).send(`Updated Student with id ${sid} in the database`)
//     }
// })
// routes.delete("/:id",async(req,res)=>{
//     const sid = parseInt(req.params.id)
//     try{
//         const deletedStudent = await studentModel.findByIdAndDelete(sid)
//         res.status(200).send(`Deletd Student with id ${sid} in the database`)
//     }catch(err){
//         res.status(400).send(`Student with id ${sid} is not present in the database`)
//     }
// })