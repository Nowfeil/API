const mongoose = require('mongoose')

mongoose.connect("mongodb://localhost:27017/StudentDatabase").then(()=>{
    console.log("connected to mongo compass succesfully");
}).catch((err)=>console.log("something wrong happened while connecting to mongoose"))

module.exports = mongoose