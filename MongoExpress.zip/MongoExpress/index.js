const express = require('express')
const app = express()
const studentRoute = require('./routes/student.route')
const mongoose = require('./mongo-connect/mongo.connect')
require('dotenv').config()

const PORT = process.env.PORT;
app.use('/api/students',studentRoute)

app.listen(PORT,()=>{console.log("connected to server successfully..")})