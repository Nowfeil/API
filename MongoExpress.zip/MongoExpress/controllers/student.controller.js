const studentModel = require('../models/student.model')
async function  getStudents(req,res){
    let students = await studentModel.find({})
    if(!students){
        res.status(400).send("No Students are there in the database")
    }else{
        res.status(200).send(students)
    }
}

async function postStudents(req,res){
    try{
        let student = await studentModel.create({
            _id:parseInt(req.body.id),
            name:req.body.name,
            branch:req.body.branch
        })
        res.status(200).send(student);
    }catch(err){
        console.log("Something went wrong while adding the student in  database");
    }
}

async function putStudents(req,res){
    const sid = parseInt(req.params.id)
    const student = await studentModel.findByIdAndUpdate(sid,req.body)
    if(!student){
        res.status(400).send(`Student with ${sid} is not present in the database`)
    }else{
        res.status(200).send(`Updated Student with id ${sid} in the database`)
    }
}

async function putStudentsBranch(req,res){
    const body = req.body
    const b1 = body.present;
    const b2 = body.update;
    try{
        const student = await studentModel.updateMany({branch:b1},{$set:{branch:b2}})
        res.send(student)
    }catch(err){
        res.status(400).send("Something went wrong while updating branch")
    }
}

async function deleteStudent(req,res){
    const sid = parseInt(req.params.id)
    try{
        const deletedStudent = await studentModel.findByIdAndDelete(sid)
        res.status(200).send(`Deletd Student with id ${sid} in the database`)
    }catch(err){
        res.status(400).send(`Student with id ${sid} is not present in the database`)
    }
}


module.exports = {getStudents,postStudents,putStudents,deleteStudent,putStudentsBranch}