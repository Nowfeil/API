let url ="http://localhost:3000/users";
function addUsers(){
    let id = document.getElementById("uid").value;
    let name = document.getElementById("uname").value;
    let branch = document.getElementById("branch").value;
    console.log(id+" "+name+" "+branch);
    fetch(url,{
        method:"POST",
        body:JSON.stringify({
            "id":id,
            "name":name,
           "branch":branch
        })
    }).then((response)=>response.json()).then((data)=>{
        console.log(data);
    })
}

let display = true;
function showUsers(){
    let table =document.getElementById('tbody');
    let btn = document.getElementById("btn-name");
    let thead = document.getElementById("thead");
    if(display === true){
        thead.innerHTML = `<th>Id</th><th>Name</th><th>Branch</th>`
        btn.innerText = "Hide"
        display = false;
        table.innerHTML = ''
        fetch(url).then((response)=>response.json()).then((data)=>{
            data.forEach((user)=>{
                let row = document.createElement("tr");
                row.innerHTML +=`<td>${user.id}</td><td>${user.name}</td><td>${user.branch}</td><td><button onclick="deleteUser(${user.id})">Delete</td><td><button onclick="editUser(${user.id})">Edit</td>`
                table.appendChild(row);
            })
        })
    }else{
        display = true;
        table.innerHTML = '';
        btn.innerText = "Show"
        thead.innerHTML = ''
    }
    
}

function deleteUser(id){
    fetch(url+`/${id}`,{
        method:"DELETE"
    }).then((response)=>response.json()).then((data)=>{
        console.log(data);
    })
}

function editUser(id) {
    document.getElementById("editForm").style.display = "block";
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            const user = data.find(users => users.id == id);
            if (user) {
                document.getElementById("Ename").value = user.name;
                document.getElementById("Ebranch").value = user.branch;
            }
            
            document.getElementById("editUserForm").onsubmit = function(event) {
                event.preventDefault();
                updateUser(id);
            };
        })
        .catch(error => console.error('Error fetching user data:', error));
}

function updateUser(id) {
    const name = document.getElementById("Ename").value;
    const branch = document.getElementById("Ebranch").value;
    
    fetch(url + `/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ name, branch })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Updated user:', data);
    })
    .catch(error => console.error('Error updating user:', error));
}



// function editUser(id){
//     document.getElementById("editForm").style.display="block"
//     fetch(url).then((response)=>response.json()).then((data)=>{
//          user = data.find((users)=>users.id==id)
//          document.getElementById("Ename").value =user.name;
//          document.getElementById("Ebranch").value = user.branch;
//          document.getElementById("form").onsubmit = ()=>{
//             updateId(id);
//          }
//     })
    
// }

// function updateId(id){
//      const name = document.getElementById("Ename").value;
//     const branch = document.getElementById("Ebranch").value;
//     fetch(url+`/${id}`,{
//         method:"PATCH",
//         body: JSON.stringify({
//             name:name,
//             branch:branch
//         })
//     }).then((response)=>response.json()).then((data)=>console.log(data))
// }