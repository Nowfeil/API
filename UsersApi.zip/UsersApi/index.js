let url ="http://localhost:3000/users";
function addUsers(){
    let id = document.getElementById("uid").value;
    let name = document.getElementById("uname").value;
    let branch = document.getElementById("branch").value;
    console.log(id+" "+name+" "+branch);
    fetch(url,{
        method:"POST",
        body:JSON.stringify({
            "id":id,
            "name":name,
           "branch":branch
        })
    }).then((response)=>response.json()).then((data)=>{
        console.log(data);
    })
}

let display = true;
function showUsers(){
    let table =document.getElementById('tbody');
    let btn = document.getElementById("btn-name");
    let thead = document.getElementById("thead");
    if(display === true){
        thead.innerHTML = `<th>Id</th><th>Name</th><th>Branch</th>`
        btn.innerText = "Hide"
        display = false;
        table.innerHTML = ''
        fetch(url).then((response)=>response.json()).then((data)=>{
            if(data.length==0){
                alert('enter all details')
                return;
            }
            data.forEach((user)=>{
                let row = document.createElement("tr");
                row.innerHTML +=`<td>${user.id}</td><td>${user.name}</td><td>${user.branch}</td><td><button onclick="deleteUser(${user.id})">Delete</td>`
                table.appendChild(row);
            })
        })
    }else{
        display = true;
        table.innerHTML = '';
        btn.innerText = "Show"
        thead.innerHTML = ''
    }
    
}

function deleteUser(id){
    fetch(url+`/${id}`,{
        method:"DELETE"
    }).then((response)=>response.json()).then((data)=>{
        console.log(data);
    })
}
